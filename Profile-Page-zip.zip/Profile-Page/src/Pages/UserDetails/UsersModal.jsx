import React, { useState } from 'react';
import { Button, Modal ,Avatar , Card , List} from 'antd';
import { useNavigate } from 'react-router-dom';


const UsersModal = (props) => {
  const navigate = useNavigate();
  const navigateToUserDetailsPage = (item) => {
    props.NavigateBack(item,props.ActualListUser)
    
  }
  return (
    <Modal 
    // title="Logout Confirmation"
    visible={props.isModalOpen}
    // onOk={props.handleOk} 
    onCancel={props.handleCancel}
    style={{
        top: 60,
        left: 450,
      }}
      width={300}
      footer={[
        // <Button key="cancel" onClick={() => props.handleCancel()}>
        //   Cancel
        // </Button>,
        <Button key="logout" type="primary" danger onClick={props.handleOk}>
          Sign Out
        </Button>,
      ]}
    >
         <div style={{ minHeight: '300px', overflowY: 'auto' }}>
      
      <Card style={{border:"none",textAlign: 'center'}}>
      <Avatar size={64} src={props.profileImage} />
      <p>{props.userName}</p>
      <p>{props.userEmail}</p>
      <div
          style={{
            maxHeight: '200px', 
            overflow: 'hidden', 
            position: 'relative', 
          }}
        >
          <div
            style={{
              maxHeight: '200px', 
              overflowY: 'scroll',
              paddingRight: '17px',
              marginRight: '-17px', 
            }}
          >
      <List
          dataSource={props.usersArray}
          renderItem={(item) => (
            <List.Item key={item.id} style={{padding:"5px"}}>
               <List.Item.Meta
                avatar={<img src={item.avatarUrl} alt={`Avatar for ${item.name}`} 
                style={{ width: '30px', height: '30px', borderRadius: '50%' ,marginRight: '10px',cursor:"pointer"}}
                onClick={()=>navigateToUserDetailsPage(item)}
                />}
                title={<span 
                    style={{ margin: 0, padding: 0 ,float: 'left' ,cursor:"pointer" }}
                    onClick={()=>navigateToUserDetailsPage(item)}
                    >{item.username}</span>}
              />
            </List.Item>
          )}
        />
        </div>
        </div>
      </Card>
      </div>
      </Modal>
  )
}

export default UsersModal