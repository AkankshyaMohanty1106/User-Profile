import React, { useState } from 'react';
import { Collapse, List } from 'antd';
import "./ExpandingDiv.css";

const { Panel } = Collapse;

const ExpandingDiv = ({ users, setChartUser }) => {
    const [collapsed, setCollapsed] = useState(true); // State to track whether Collapse is collapsed or not

    // Toggle the collapsed state when the Collapse panel is clicked
    const toggleCollapse = () => {
        setCollapsed(!collapsed);
        
    };

    const navigateToUserDetailsPage = (item) => {
        setChartUser(item);
        setCollapsed(true);
    };

    return (
        <div className="custom-container">
            <Collapse
                defaultActiveKey={[]}
                ghost
                activeKey={collapsed ? [] : ['1']} // Set activeKey based on the collapsed state
                onChange={toggleCollapse} // Toggle collapsed state when the panel is clicked
            >
                <Panel header="User List" key="1" className="custom-panel">
                    <div
                        style={{
                            maxHeight: '200px',
                            overflow: 'hidden',
                            position: 'relative',
                        }}
                    >
                        <div
                            style={{
                                width: "200px",
                                maxHeight: '200px',
                                overflowY: 'scroll',
                                paddingRight: '17px',
                                marginRight: '-17px',
                            }}
                        >
                            <List
                                dataSource={users}
                                renderItem={(item) => (
                                    <List.Item key={item.id}>
                                        <List.Item.Meta
                                            avatar={<img
                                                src={item.avatarUrl}
                                                alt={`Avatar for ${item.name}`}
                                                style={{
                                                    width: '30px',
                                                    height: '30px',
                                                    borderRadius: '50%',
                                                    marginRight: '10px',
                                                    cursor: "pointer"
                                                }}
                                                onClick={() => navigateToUserDetailsPage(item)}
                                            />}
                                            title={<span
                                                style={{ margin: 0, padding: 0, float: 'left', cursor: "pointer" }}
                                                onClick={() => navigateToUserDetailsPage(item)}
                                            >{item.username}</span>}
                                        />
                                    </List.Item>
                                )}
                            />
                        </div>
                    </div>
                </Panel>
            </Collapse>
        </div>
    );
};

export default ExpandingDiv;
