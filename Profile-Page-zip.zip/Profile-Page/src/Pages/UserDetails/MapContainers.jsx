import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const mapStyle = {
  height: "230px",
  width: "100%",
};

const MapContainers = (props) => {
  const { lat, lng } = props;

  // const initialPosition = [52.505, -0.03];
  // const initialPosition = [29.4572, -164.299]
  // const initialPosition = [Number(lat), Number(lng)];
  let initialPosition = [Number(lat), Number(lng)];

  if (isNaN(initialPosition[0]) || isNaN(initialPosition[1])) {
    initialPosition = [52.505, -0.03];
  }

  return (
    <MapContainer center={initialPosition} zoom={13} style={mapStyle}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />
      <Marker position={initialPosition}>
        <Popup>A sample location on OpenStreetMap!</Popup>
      </Marker>
    </MapContainer>
  );
};

export default MapContainers;
