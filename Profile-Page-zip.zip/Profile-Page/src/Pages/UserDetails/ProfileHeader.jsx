import React from 'react';
import { Layout, Avatar, Typography } from 'antd';
import { useNavigate } from 'react-router-dom';
import UsersModal from './UsersModal';

const { Header } = Layout;
const { Title } = Typography;

const ProfileHeader = ({ profileName, profileImage ,users,email,setNewItem,setNewUsers}) => {
  const navigate = useNavigate();
  const [openUserModal,setOpenUserModal] = React.useState(false);
  const [usersArray,setUsersArray] = React.useState([]);
  // console.log("users",users)

  const handleOk = () => {
    setOpenUserModal(false);
    navigate("/")
  }
  const NavigateBack  = (item,actualUserList) => {
    setNewItem(item);
    setNewUsers(actualUserList);
    setOpenUserModal(false);
  }

  return (
    <>
    <Header style={{ background: '#fff', padding: '0 16px', display: 'flex', alignItems: 'center',justifyContent:"space-between" }}>
     
     <div style={{ display: 'flex', alignItems: 'center' }}>
        <Title level={3} style={{ margin: 0, marginRight: '8px' }}>Profile</Title>
      </div>

      
      <div style={{ display: 'flex', alignItems: 'center',cursor:"pointer" }} onClick={()=>{
        let newUsersArray = users.filter((user)=>user.username !== profileName);
        setUsersArray(newUsersArray);
        setOpenUserModal(true);
      }}>
        <Avatar src={profileImage} size={40} style={{ marginRight: '8px' }} />
        <Title level={4} style={{ margin: 0 }}>{profileName}</Title>
      </div>
    </Header>
    {openUserModal && (
      <UsersModal
      isModalOpen={openUserModal}
      handleOk ={handleOk}
      handleCancel = {() => setOpenUserModal(false)}
      usersArray={usersArray}
      userName = {profileName}
      userEmail = {email}
      profileImage = {profileImage}
      ActualListUser = {users}
      NavigateBack = {NavigateBack}
      />
    )}
    </>
  )
}

export default ProfileHeader