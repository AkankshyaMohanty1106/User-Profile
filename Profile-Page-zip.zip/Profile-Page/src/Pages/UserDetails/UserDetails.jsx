// UserDetails.js
import React, { useState, useEffect } from "react";
import { Layout } from "antd";
import { Switch, Route } from "react-router-dom";
import { Outlet } from "react-router-dom";
import Profile from "./Profile";
import Posts from "./Posts";
import Gallery from "./Gallery";
import ToDo from "./ToDo";
import LeftSidebar from "./LeftSidebar";
import { useNavigate, useLocation } from "react-router-dom";
import ProfileHeader from "./ProfileHeader";

const { Sider, Content } = Layout;

const UserDetails = () => {
  const location = useLocation();
  const [selectedMenuItem, setSelectedMenuItem] = useState("1");
  const [usersitem, setUsers] = useState(location.state.users);
  const [item, setItem] = useState(location.state.item);
  const [reRander,setRander] = useState(false);
  // const users = location.state.users;
  // useEffect(()=>{
  //   if(reRander){
  //     setRander(!reRander);
  //   }
  // },[reRander])
  const handleMenuClick = ({ key }) => {
    setSelectedMenuItem(key);
  };
  
  const onChangeItem = (e) => {
    
    setItem(e);
    
  }

  return (
    // <Router>
    <Layout style={{ minHeight: "100vh" }}>
      <Sider
        width={200}
        theme="dark"
        style={{
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div
          style={{
            flex: "1",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <LeftSidebar handleMenuClick={handleMenuClick} />
        </div>
      </Sider>
      <Layout>
        <ProfileHeader
          profileName={item.username}
          profileImage={item.avatarUrl}
          users={usersitem}
          email={item.email}
          setNewItem={(e)=>onChangeItem(e)}
          setNewUsers={setUsers}
        />
        
          <Content>
            {selectedMenuItem === "1" && (
              <Profile item={item} users={usersitem} >
                {console.log(item)}
              </Profile>
            )}
            {selectedMenuItem === "2" && <Posts />}
            {selectedMenuItem === "3" && <Gallery />}
            {selectedMenuItem === "4" && <ToDo />}
          </Content>
        
      </Layout>
    </Layout>
    // </Router>
  );
};

export default UserDetails;
