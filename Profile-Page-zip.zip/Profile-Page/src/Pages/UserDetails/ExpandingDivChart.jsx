import React, { useState } from 'react';
import { Collapse, Avatar } from 'antd';
import "./ExpandingDivChart.css";
import { Input, Button, List } from 'antd';

const { Panel } = Collapse;
const ExpandingDivChart = ({chartUser }) => {
    const [collapsed, setCollapsed] = useState(true);
    console.log("chartUser", chartUser.username)

    const togglePanel = () => {
        setCollapsed(!collapsed);
    };

    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState([]);

    const handleSendMessage = () => {
        if (message.trim() !== '') {
            setMessages([...messages, message]);
            setMessage('');
        }
    };

    return (
        <div className="custom-container">
            <Collapse
                ghost
                activeKey={collapsed ? [] : ['1']} // Set activeKey based on the collapsed state
                onChange={togglePanel} // Toggle collapsed state when the panel is clicked
            >
                <Panel header={`${chartUser.username} Chart`} key="1" className="custom-panel">
                    <div
                        style={{
                            maxHeight: '200px',
                            overflow: 'hidden',
                            position: 'relative',
                        }}
                    >
                        <div
                            style={{
                                width: "200px",
                                maxHeight: '200px',
                                overflowY: 'scroll',
                                paddingRight: '17px',
                                marginRight: '-17px',
                            }}
                        >
                            <div>
                                <div className="chat-messages">
                                    <List
                                        itemLayout="horizontal"
                                        dataSource={messages}
                                        renderItem={(msg) => (
                                            <List.Item>
                                                <List.Item.Meta title={msg} />
                                            </List.Item>
                                        )}
                                    />
                                </div>
                                <div className="chat-input">
                                    <Input
                                        placeholder="Type a message..."
                                        value={message}
                                        onChange={(e) => setMessage(e.target.value)}
                                        onPressEnter={handleSendMessage}
                                    />
                                    <Button type="primary" onClick={handleSendMessage}>
                                        Send
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </Panel>
            </Collapse>
        </div>
    )
}

export default ExpandingDivChart;
