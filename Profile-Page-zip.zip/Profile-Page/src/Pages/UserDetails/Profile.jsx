import React, { useState ,useEffect} from "react";
import { Layout, Row, Col } from "antd";
import ProfileHeader from "./ProfileHeader";
import UserInfo from "./UserInfo";
import AddressInfo from "./AddressInfo";
import styled from "styled-components";
import { Button } from "antd";
import ExpandingDiv from "./ExpandingDiv";
import ExpandingDivChart from "./ExpandingDivChart";

const { Content } = Layout;

const Container = styled.div`
  display: flex;
  height: 88vh;
`;

const LeftCol = styled(Col)`
  background-color: #fff;
  // padding: 20px;
  border-radius: 0;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
`;

const RightCol = styled(Col)`
  background-color: #fff;
  padding: 20px;
  border-radius: 0;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
`;

function Profile(props) {
  const [item,setItem] = useState();
  // const [users,setUsers] = useState(props.users)
  const [showMessageOverlay, setShowMessageOverlay] = useState(false);
  const [user,setuser] = useState({
    
  });
  const [address , setAddress] = useState({
    
  });
  const [chartUser,setChartUser] = useState();
  const chatData = [
    {
      user: {
        name: 'User 1',
        avatar: 'url_to_avatar1',
      },
      messages: ['Message 1', 'Message 2'],
    },
    
  ];
 

  console.log("item",item)

  useEffect(()=>{
    setItem(props.item);
    setuser({
      photo: props.item.avatarUrl || '',
      name: props.item.name || '',
      username: props.item.username || '',
      email: props.item.email || '',
      phone: props.item.phone || '',
      website: props.item.website || '',
      company: {
        name: props.item.company.name || '',
        catchphrase: props.item.company.catchPhrase || '',
        bs: props.item.company.bs || '',
      },
    })
    setAddress({
      street: props.item.address ? props.item.address.street || '' : '',
    suite: props.item.address ? props.item.address.suite || '' : '',
    city: props.item.address ? props.item.address.city || '' : '',
    zipcode: props.item.address ? props.item.address.zipcode || '' : '',
    geo: props.item.address ? props.item.address.geo || '' : '',
    })
  },[props.item])
  const openMessageOverlay = () => {
    setShowMessageOverlay(true);
  }
  
  return (
    <Layout>
      {/* <ProfileHeader profileName={item.username} profileImage={item.avatarUrl} users={users} email = {item.email} setNewItem={setItem} setNewUsers={setUsers}/> */}
      <Content>
        <Container>
          <LeftCol span={12}>
            {Object.keys(user).length !== 0 && (
              <UserInfo user={user} />
            )}
            <div style={{display:"flex",float:"right"}}>
            <div>
            {chartUser && (
              <ExpandingDivChart chartUser={chartUser} />
            )}
            </div>
            <div>
              <ExpandingDiv users={props.users} setChartUser={setChartUser}/>
            </div>
            </div>
          </LeftCol>
          <RightCol span={12}>
          {Object.keys(address).length !== 0 && (
            <AddressInfo address={address} />
          )}
            
          </RightCol>
        </Container>
        
      </Content>
      
    </Layout>
  );
}

export default Profile;
