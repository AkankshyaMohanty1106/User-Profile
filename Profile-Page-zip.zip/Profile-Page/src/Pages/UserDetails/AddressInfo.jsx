// AddressInfo.js
import React from 'react';
import { Card } from 'antd';
import MapContainers from './MapContainers';

const mapStyles = {
  width: '100%',
  height: '400px',
};

const AddressInfo = ({ address }) => {
  return (
    <Card style={{border:"none"}}>
      <p>Street: {address.street}</p>
      <p>Suite: {address.suite}</p>
      <p>City: {address.city}</p>
      <p>Zipcode: {address.zipcode}</p>
      <MapContainers lat={address.geo.lat} lng={address.geo.lng}/>
    </Card>
  );
};

export default AddressInfo;
