// LeftSidebar.js
import React from 'react';
import { Layout, Menu } from 'antd';
import { Link, useLocation } from 'react-router-dom';
import { UserOutlined, NotificationOutlined } from '@ant-design/icons';

const { Sider } = Layout;

const LeftSidebar = ({ handleMenuClick }) => {
  const location = useLocation();

  return (
    <Menu mode="vertical" defaultSelectedKeys={"1"} theme="dark" style={{ paddingTop: '200px' }} onClick={handleMenuClick}>
      <Menu.Item key="1" icon={<UserOutlined />}>Profile</Menu.Item>
      <Menu.Item key="2" icon={<NotificationOutlined />}>Posts</Menu.Item>
      <Menu.Item key="3" icon={<NotificationOutlined />}>Gallery</Menu.Item>
      <Menu.Item key="4" icon={<NotificationOutlined />}>ToDo</Menu.Item>
    </Menu>
  );
};

export default LeftSidebar;
