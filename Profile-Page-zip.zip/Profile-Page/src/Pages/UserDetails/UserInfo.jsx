// UserInfo.js
import React from 'react';
import { Card, Avatar } from 'antd';

const UserInfo = ({ user }) => {
  return (
    <Card style={{border:"none"}}>
      <Avatar size={64} src={user.photo} />
      <p>Name: {user.name}</p>
      <p>Username: {user.username}</p>
      <p>Email: {user.email}</p>
      <p>Phone: {user.phone}</p>
      <p>Website: {user.website}</p>
      <div style={{fontWeight:"700"}}>Company</div>
      <p>CompanyName: {user.company.name}</p>
      <p>Catchphrase: {user.company.catchphrase}</p>
      <p>Bs: {user.company.bs}</p>
    </Card>
  );
};

export default UserInfo;
