import React from 'react';
import { Result } from 'antd';

const Gallery = () => {
  return (
    // <div>Coming Soon</div>
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
      <Result
        status="404"
        title="Coming Soon"
        subTitle="This page is currently under construction. Please check back later."
      />
    </div>
  )
}

export default Gallery