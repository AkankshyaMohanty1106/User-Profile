import React , {useState,useEffect} from 'react';
import { Card, List } from 'antd';
import {accountListFun} from "../Services/AccountService";
import { useNavigate } from 'react-router-dom';

const Account = () => {
    const navigate = useNavigate();
    const [userAccounts, setUsers] = useState([]);
    // const userAccounts = [
    //     { id: 1, name: 'User 1', avatarUrl: 'https://via.placeholder.com/100.png/09f/fff' },
    //     { id: 2, name: 'User 2', avatarUrl: 'https://via.placeholder.com/100.png/09f/fff' },
    //     { id: 3, name: 'User 3', avatarUrl: 'https://via.placeholder.com/100.png/09f/fff' },
    //     // Add more user accounts as needed
    // ];
    useEffect(()=>{
        accountListFun().then((resp)=>{
            // console.log(resp.users)
            let formatedUSerList = resp.users.map((user,index)=>{
                return {
                    id: user.id,
                    name: user.name, 
                    avatarUrl: user.profilepicture,
                    address : user.address,
                    company : user.company,
                    email : user.email,
                    phone : user.phone,
                    username : user.username,
                    website : user.website
                }
            })
            setUsers(formatedUSerList)
        })
    },[])
    const navigateToUserDetailsPage = (item) => {
        navigate("/user-details",{
          state : {
            item : item,
            users : userAccounts,
          }
        })
    }
  return (
    <div>
        <div className='accountList-header'>
            <h3>Select Account</h3>
        </div>
        <div className='account-list'>
        <Card style={{ border: 'none'}}>
        <List
          dataSource={userAccounts}
          renderItem={(item) => (
            <List.Item key={item.id} style={{padding:"5px"}}>
               <List.Item.Meta
                avatar={<img src={item.avatarUrl} alt={`Avatar for ${item.name}`} 
                style={{ width: '30px', height: '30px', borderRadius: '50%' ,marginRight: '10px',cursor:"pointer"}}
                onClick={()=>navigateToUserDetailsPage(item)}
                />}
                title={<span 
                    style={{ margin: 0, padding: 0 ,float: 'left' ,cursor:"pointer" }}
                    onClick={()=>navigateToUserDetailsPage(item)}
                    >{item.username}</span>}
              />
            </List.Item>
          )}
        />
      </Card>
        </div>
    </div>
  )
}

export default Account