import './App.css';
import Account from './Pages/Account';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import UserDetails from './Pages/UserDetails/UserDetails';
// import Profile from './Pages/UserDetails/Profile';
// import Posts from './Pages/UserDetails/Posts';
// import Gallery from './Pages/UserDetails/Gallery';
// import ToDo from './Pages/UserDetails/ToDo';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<div className='Account-Contaner'><Account /></div>} />
          <Route path="/user-details" element={<UserDetails/>} />
          {/* <Route path="/user-details/profile" element={<Profile/>} />
          <Route path="/user-details/post" element={<Posts/>} />
          <Route path="/user-details/gallery" element={<Gallery/>} />
          <Route path="/user-details/todo" element={<ToDo/>} /> */}
        </Routes>
      </Router>
    </div>
  );
}

export default App;
