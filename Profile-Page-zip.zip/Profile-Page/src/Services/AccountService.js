import axios from "axios";

export const accountListFun = async() => {
    try {
        const resp = await axios.get('https://panorbit.in/api/users.json');
        return resp.data;
      } catch (error) {
        return error;
      }
}